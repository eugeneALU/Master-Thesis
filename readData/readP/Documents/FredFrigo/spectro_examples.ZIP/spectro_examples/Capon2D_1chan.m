% spectrum2D.m - mainline function to evaluate 2D Capon / 2D APES
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
% Fred J. Frigo, James A. Heinen
%
% This is the main MATLAB code used to analyze:
%   weighted 2D Capon 
%   weighted 2D APES
%   combined weighted 2D APES / 2D APES
%   2D multiple-channel spectral estimation using signal averaging
%   2D multiple-channel spectral estimation using spectrum averaging
%
% Use datatype=1 to use simulated test signal or
%     datatype=2 to use phase-corrected, water-suppressed MRS data
%
% Note:
%   Standard 2D Capon:   alp1=alp2=bet1=bet2=gam=0;   spectrumtype=1
%   Standard 2D APES: alp1=alp2=bet1=bet2=0; gam=1;   spectrumtype=2
%
%   Run "spectro.m" first to create a *.signal.dat file from a Pfile.
%   This is the water-suppressed, phase-corrected data with residual water
%   removed.  For 3T there are 4096 data points, for 1.5T there are 2048
%
clear all
close all
N=3584;%1792;  %512   % Note: for MRS data N+M should = 2048 for optimum results!
M=512;%256;   %128
Ns=3600;   %1800
Nf=4096;%0<Ns<Nf.  Nf>=N+M-1.  %2048
K=N;%K must be 1 or N.  alp1 and alp2 are irrelevant if K=1.
Nsig=40;
Nw=N/2;%Nw must be greater than or equal to N/2.
k1=0;
k2=Nw-1;%0<=k1<k2<=Nw-1.
delsig=0.0001;
alp1=0;
alp2=0;
bet1=0;  % 0 = default - set this to 0.5 to increase peak picking sensitivity
bet2=0;
gam=0;%0<gam<=1.  gam=1 reduces to 2D APES.  gam=0 would reduce to 2D Capon.
C=1;  % number of channels

datatype=2;%=1 for simulated data, 2 for mrs data.
spectrumtype=1;%=1 for 2D Capon, 2 for 2D APES/Capon.

if C>1
   combotype=1;%=1 for signal averaging, 2 for spectrum averaging, 3 for composite spectrum.
   gtype=2;%=1 for ideal g's, 2 for estimated g's.
           %ideal can be used only for simulated data.
   rhosqtype=2;%=1 for ideal rhosq's, 2 for estimated rhosq's.
               %ideal can be used only for simulated data.
end
 
tempC=37;
delw=pi/Nw;
mrs_name='x(t)';
if datatype==1
   gideal=[1];%[0.5*j+0.4 0.2 0.15+j*3 0.15-j*3].';%length(gideal)=C.  If C=1, then gideal=1.
   dbSNRideal=[0];%[40 40 40 40].';%length(dbSNRideal)=C.
   [xlong,xclean,rhosqideal]=getx(Nf,delw,C,gideal,dbSNRideal);
elseif datatype==2
   [xlong,dbSNRideal,mrs_name]=getxmrs(Nf,C);
   tempC=22  %37
   %[xlong,dbSNRideal,mrs_name]=getxmrs_invivo(Nf,C);
   %[xlong,dbSNRideal,mrs_name]=getxmrs_sphere(Nf,C);
   k1=floor(0.02*Nw/pi);
   k2=floor(0.8*Nw/pi);
end

x=xlong(:,1:N+M-1);

if C>1
   
   if gtype==1&datatype==1
      g=gideal;
   elseif gtype==2
      g=fgest(xlong,C);
      %g=fgest(x,C);
   end
   
   if rhosqtype==1&datatype==1
      rhosq=rhosqideal;
   elseif rhosqtype==2
      rhosq=frhosqest(xlong,Ns,Nf,C);
   end
   
   Rw=diag(rhosq);
   Rwinv=inv(Rw);   
   w=Rwinv*g/(g'*Rwinv*g);
   xest=w'*x;

else % if C == 1, then g = 1
    g=1;
end

tic

if (C==1)|(C>1&combotype==3)
   if spectrumtype==1
      S=Capon2D(x,N,M,K,Nsig,Nw,k1,k2,delsig,alp1,alp2,bet1,bet2,C,g);
   elseif spectrumtype==2
      S=APESCapon2D(x,N,M,Nsig,Nw,k1,k2,delsig,bet1,bet2,gam,C,g);
   end
end

if C>1&combotype==1
   if spectrumtype==1
      S=Capon2D(xest,N,M,K,Nsig,Nw,k1,k2,delsig,alp1,alp2,bet1,bet2,1,1);
   elseif spectrumtype==2
      S=APESCapon2D(xest,N,M,Nsig,Nw,k1,k2,delsig,bet1,bet2,gam,1,1);
   end
end

if C>1&combotype==2
   S=zeros(Nsig,k2-k1+1);
   for i=1:C
      if spectrumtype==1
         Si=Capon2D(x(i,:),N,M,K,Nsig,Nw,k1,k2,delsig,alp1,alp2,bet1,bet2,1,1);
      elseif spectrumtype==2
         Si=APESCapon2D(x(i,:),N,M,Nsig,Nw,k1,k2,delsig,bet1,bet2,gam,1,1);
      end
      S=S+conj(w(i))*Si;
   end
end

toc

if spectrumtype==1
   paras=['N = ',num2str(N),', M = ',num2str(M),', K = ',num2str(K),...
         ', alp1 = ',num2str(alp1),', alp2 = ',num2str(alp2),...
         ', bet1 = ',num2str(bet1),', bet2 = ',num2str(bet2),...
         ', SNR = ',num2str(dbSNRideal'),' db'];
elseif spectrumtype==2
   paras=['N = ',num2str(N),', M = ',num2str(M),...
         ', bet1 = ',num2str(bet1),', bet2 = ',num2str(bet2),...
         ', gam = ',num2str(gam),', SNR = ',num2str(dbSNRideal'),' db'];
end

sigset=delsig*[0:Nsig-1];
wset=delw*[k1:k2];
n=[0:N+M-2];

Sp=peak(S,0,1);
Spp=peakproj(Sp,0);

% create projection of the non-peak enhanced spectrum (fig38 phD)
rawSpp=peakproj(abs(S), 0);

% Plots
if( spectrumtype == 1)
  analysis_string = '2D Capon ';
else
  analysis_string = '2D Capon/APES ';
end

figure
title_string = strcat([analysis_string, 'surface plot of |S(\sigma,\omega)| for ', mrs_name]); 
surf(wset,sigset,abs(S)),title(title_string), xlabel('\omega'), ylabel('\sigma'),zlabel('|S(\sigma,\omega)|');

figure
title_string = strcat([analysis_string, 'contour plot of |S(\sigma,\omega)| for ', mrs_name]); 
contour(wset,sigset,abs(S)),title(title_string),xlabel('\omega'),ylabel('\sigma');

figure
title_string = strcat([analysis_string, 'peak-enhanced surface plot of |S(\sigma,\omega)| for ', mrs_name]); 
surf(wset,sigset,Sp),title(title_string),xlabel('\omega'),ylabel('\sigma'),zlabel('|S(\sigma,\omega)|');
 
figure
title_string = strcat([analysis_string, 'peak-enhanced contour plot of |S(\sigma,\omega)| for ', mrs_name]); 
contour(wset,sigset,Sp),title(title_string),xlabel('\omega'),ylabel('\sigma');
% using sign(Sp) causes all peaks to be shown, no matter how small
% contour(wset,sigset,sign(Sp)),title(title_string),xlabel('\omega'),ylabel('\sigma');

figure
title_string = strcat([analysis_string, 'projected peaks of |S(\sigma,\omega)| for ', mrs_name]); 
plot(wset,Spp),title(title_string),xlabel('\omega'),ylabel('|S(\sigma,\omega)|');

figure
title_string = strcat([analysis_string, 'projection of |S(\sigma,\omega)| for ', mrs_name]); 
plot(wset,rawSpp),title(title_string),xlabel('\omega'),ylabel('|S(\sigma,\omega)|');

X=fft(x.').';
[Cft,Nft]=size(abs(X));
k1ft=floor(Nft*k1/(2*Nw));
k2ft=floor(Nft*k2/(2*Nw));
wfset=[k1ft:k2ft]*2*pi/Nft;
figure
plot(wfset,abs(X(:,k1ft+1:k2ft+1))/Nft),title(strcat(['Fourier transform of ',mrs_name])),xlabel('\omega'),ylabel('|S(\omega)|');
%plot(wfset,abs(X(:,k1ft+1:k2ft+1))/Nft),title('abs(FFT)s of observed signal(s)'),xlabel(paras)
if C>1
   Xest=fft(xest.').';
   figure
   plot(wfset,abs(Xest(:,k1ft+1:k2ft+1))/Nft),title('average abs(FFT)'),xlabel(paras)
end
figure
plot(n,abs(x).'),title(strcat(['Input signal ',mrs_name])), xlabel('t'),ylabel('x(t)');
%plot(n,abs(x).'),title('observed signal(s)'),xlabel(paras)

% Plots identical to above, but scaled to ppm axis.
% PPM axis  ( calibrated for 37C )
% tempC must be set for proper ppm axis scaling. (tempC=37) for in vivo
ppm_start_37C = -4.55;  
ppm_stop_37C = 0.30;
ppm_per_degree_C=0.01;
ppm_offset = (tempC-37)*ppm_per_degree_C;
ppm_start = ppm_start_37C + ppm_offset;
ppm_stop = ppm_stop_37C + ppm_offset;
ppm_x = linspace(ppm_start,ppm_stop,(k2-k1+1));


figure
title_string = strcat([analysis_string, 'surface plot of |S(\sigma,\omega)| for ', mrs_name]); 
surf(ppm_x,sigset,abs(S)), xlabel('ppm'), ylabel('\sigma'),zlabel('|S(\sigma,\omega)|');
set(gca,'XTick',-4.0:1.0:0.0);
set(gca,'XTickLabel',{'4.0','3.0','2.0','1.0','0.0'});

figure
title_string = strcat([analysis_string, 'contour plot of |S(\sigma,\omega)| for ', mrs_name]); 
contour(ppm_x,sigset,abs(S)),xlabel('ppm'),ylabel('\sigma');
set(gca,'XTick',-4.0:1.0:0.0);
set(gca,'XTickLabel',{'4.0','3.0','2.0','1.0','0.0'});

figure
title_string = strcat([analysis_string, 'peak enhanced surface plot of |S(\sigma,\omega)| for ', mrs_name]); 
surf(ppm_x,sigset,Sp),xlabel('ppm'),ylabel('\sigma'),zlabel('|S(\sigma,\omega)|');
set(gca,'XTick',-4.0:1.0:0.0);
set(gca,'XTickLabel',{'4.0','3.0','2.0','1.0','0.0'});

figure
title_string = strcat([analysis_string, 'peak enhanced contour plot of |S(\sigma,\omega)| for ', mrs_name]); 
contour(ppm_x,sigset,Sp),xlabel('ppm'),ylabel('\sigma');
set(gca,'XTick',-4.0:1.0:0.0);
set(gca,'XTickLabel',{'4.0','3.0','2.0','1.0','0.0'});

figure
title_string = strcat([analysis_string, 'projected peaks of |S(\sigma,\omega)| for ', mrs_name]); 
plot(ppm_x,Spp),xlabel('ppm'),ylabel('|S(\sigma,\omega)|');
set(gca,'XTick',-4.0:1.0:0.0);
set(gca,'XTickLabel',{'4.0','3.0','2.0','1.0','0.0'});



