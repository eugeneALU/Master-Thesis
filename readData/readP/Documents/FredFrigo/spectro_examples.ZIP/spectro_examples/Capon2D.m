% Capon2D.m - weighted 2D Capon
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
%  Fred J. Frigo, James A. Heinen
%
% K must be 1 or N.  alp1 and alp2 are irrelevant if K=1.
% Nw must be greater than or equal to N/2.
% k1 and k2 must satisfy 0<=k1<k2<=Nw-1.
% If bet1=0, only one matrix inversion is used.
% If alp1=-0.5 and alp2=0, only one fft is used.
% If K=1, no fft's are used.
%
function S=Capon2D(x,N,M,K,Nsig,Nw,k1,k2,delsig,alp1,alp2,bet1,bet2,C,g)

delw=pi/Nw;
x1=x(1,:);
xbb=x1(ones(M,1)*[1:N]+[0:M-1]'*ones(1,N));
if C>1
   for i=2:C
      xi=x(i,:);
      xbb=[xbb
         xi(ones(M,1)*[1:N]+[0:M-1]'*ones(1,N))];
   end
end
if bet1==0
   bet=bet2;
   Rinv=fRinv(xbb,N,M,bet,C);
end
if K==1
   Xbb=repmat(x(1,1:M).',1,Nw);
   if C>1
      for i=2:C
         Xbb=[Xbb
            repmat(x(i,1:M).',1,Nw)];
      end
   end
elseif (K~=1)&(alp1==-0.5&alp2==0)
   Xbb=fXbb(xbb,N,M,Nw,0,C);
end
for m=0:Nsig-1
   sig=m*delsig;
   if bet1~=0
      bet=bet1*sig+bet2;
      Rinv=fRinv(xbb,N,M,bet,C);
   end
   if K==1
      L=1;
   elseif (K~=1)&(alp1==-0.5&alp2==0)
      L=fL(N,0.5*sig);
   else
      alp=alp1*sig+alp2;
      Xbb=fXbb(xbb,N,M,Nw,sig+2*alp,C);
      L=fL(N,sig+alp);
   end
   sbb0=exp(-sig*[0:M-1]'*ones(1,k2-k1+1)+j*delw*[0:M-1]'*[k1:k2]);
   sbb=g(1)*sbb0;
   if C>1
      for i=2:C
         sbb=[sbb
            g(i)*sbb0];
      end
   end
   S(m+1,:)=(ones(1,M*C)*(conj(sbb).*(Rinv*Xbb(:,k1+1:k2+1))))./...
      (L*ones(1,M*C)*(conj(sbb).*(Rinv*sbb)));
end
return

function Rinv=fRinv(xbb,N,M,bet,C)
e=repmat(exp(-bet*[0:N-1]),M*C,1);
xbbe=xbb.*e;
R=xbbe*xbbe';
Rinv=inv(R);
return

function Xbb=fXbb(xbb,N,M,Nw,sig,C)
e=repmat(exp(-sig*[0:N-1]),M*C,1);
xbbe=xbb.*e;
Xbb=fft(xbbe.',2*Nw).';
return

function L=fL(N,sig)
if sig==0
   L=N;
else
   L=(1-exp(-2*sig*N))/(1-exp(-2*sig));
end
return