% peakproj.m - Create peak projection plot of a 2D surface
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
%  Fred J. Frigo, James A. Heinen
%
function Spp=peakproj(S,thresh)
S=abs(S);
[Nsig,Nw]=size(S);
for k=1:Nw
   Spp(k)=max(S(:,k));
   if Spp(k)<=thresh
      Spp(k)=0;
   end
end
return