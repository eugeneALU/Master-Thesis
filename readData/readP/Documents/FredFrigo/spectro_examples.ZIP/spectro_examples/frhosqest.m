% frhosqest.m  - multiple-channel rho-sqaured (noise variance) estimation for FID signal
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
%  Fred J. Frigo, James A. Heinen
%
% xlong is the matrix containing signals from C channels
%
% Ns = length of signal (high SRN region of FID signal)
% Nf = total length of FID signal.
%
% note:  rho^2 is estimated from "noisy" end of FID signal
%

function rhosqest=frhosqest(xlong,Ns,Nf,C)
xrho=xlong(:,Ns+1:Nf);
for i=1:C
   rhosqest(i)=xrho(i,:)*xrho(i,:)';
end
rhosqest=rhosqest.'/(Nf-Ns);
return