Magnetic Resonance Spectroscopy
Marquette University
Fred J. Frigo
15-Feb-2011


The 2D Capon and 2D APES processing examples require that
the "spectro" utility is first run on a Pfile containing
the MR spectroscopy raw data.

From the MATLAB prompt, type:

>> spectro

This will prompt user to select Pfile with raw data.
Select the a Pfile that contains raw data from an MRS sphere.

P36864.7 - single channel head coil

An MRS absorption spectrum is computed and a new file called
P36864.7.signal.dat is created.  This file contains an average 
of all the water-suppressed data from the Pfile.  This file 
will be used as an input to the 2D Capon and 2D APES processing 
functions.

>> Capon2D

This will prompt the user to select the "*.signal.dat" file
containing water-suppressed raw data.

P36864.7.signal.dat

After about 30 seconds a set of plots with 2D Capon results
will be generated.  


The APES2D and Spectrum2D commands may also be used
with the P36964.7.signal.dat file.

Note: parameter tweaking may be required to get meaningful results.


==========================================================

Tested with MATLAB 7.6.0 with Image Processing Toolkit.