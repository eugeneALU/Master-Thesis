% getxmrs.m - read phase-corrected, water-suppressed MRS signal
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
% Fred J. Frigo, James A. Heinen
%
% Note: If C > 1, a file for each receive channel will be obtained.
%
function [xlong,dbSNRideal,fname]=getxmrs(Nf,C);
for i=1:C
   [fname, pname] = uigetfile('*.*', 'Select spectroscopy raw data file (signal.dat)');
   afile = strcat(pname, fname);
   fid = fopen(afile,'r', 'ieee-le');
   [raw_data, count] = fread(fid, inf, 'real*4'); 
   fclose(fid);
   for m = 1:(count/2)
        frame_data(m) = raw_data((2*m)-1) + j*raw_data(2*m);
   end
   xi=frame_data(1:Nf)*0.0001;
   xeng(i)=xi*xi';
   if i==1
      xlong=xi;
   else
      xlong=[xlong
         xi];
   end
end
dbSNRideal=NaN;
return
