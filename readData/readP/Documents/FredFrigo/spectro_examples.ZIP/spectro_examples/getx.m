% getx.m - get simulated test signal (5 different damped sinusoid components)
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
%  Fred J. Frigo, James A. Heinen
%
% note: if C > 1, a set of test signals is created, each with a different
%       SNR and gain as specified by gideal, dbSNRideal
%
function [xlong,xclean,rhosqideal]=getx(Nf,delw,C,gideal,dbSNRideal)
n=[0:Nf-1];
t=n;
xclean=2*exp(j*pi/3)*exp((-0.003+j*20*delw)*t);
xclean=xclean+4*exp(-j*pi/6)*exp((-0.008+j*25*delw)*t);
xclean=xclean+2*exp(j*pi)*exp((-0.001+j*50*delw)*t);
xclean=xclean+4*exp(j*pi/6)*exp((-0.008+j*210*delw)*t);
xclean=xclean+2*exp(-j*pi/3)*exp((-0.003+j*220*delw)*t);
xeng=xclean*xclean';
for i=1:C
   noise=(randn(size(xclean)))+j*(randn(size(xclean)));
   neng=noise*noise';
   noisegain(i)=sqrt((abs(gideal(i))^2*xeng)/(neng*10^(dbSNRideal(i)/10)));
   noisei=noisegain(i)*noise;
   rhosqideal(i)=noisei*noisei'/Nf;
   xi=gideal(i)*xclean+noisei;
   if i==1
      xlong=xi;
   else
      xlong=[xlong
         xi];
   end
end
rhosqideal=rhosqideal.';
return
