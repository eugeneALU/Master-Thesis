% fgest.m - gain estimation for multiple-channel signals for FID signal
% Marquette University,   Milwaukee, WI  USA
% Copyright 2003, 2004 - All rights reserved.
%  Fred J. Frigo, James A. Heinen
%
% xlong is the matrix containing signals from C channels
%
function gest=fgest(xlong,C)
one=ones(C,1);
R=xlong*xlong';
Rg=R-trace(R)*eye(C);
RgRginv=inv(Rg'*Rg);
gest=RgRginv*one/(one'*RgRginv*one);
return