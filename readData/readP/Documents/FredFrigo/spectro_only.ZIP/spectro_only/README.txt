Magnetic Resonance Spectroscopy
Marquette University
Fred J. Frigo
15-Feb-2011

From the MATLAB prompt, type:

>> spectro

This will prompt user to select Pfile with raw data.
Select the a Pfile that contains raw data from an MRS sphere.

P36864.7 - single channel head coil

An MRS absorption spectrum is computed.

==========================================================

Tested with MATLAB 7.6.0 with Image Processing Toolkit.