Echo Planar Image (EPI) reconstruction
Marquette University - EECE 5510
Fred J. Frigo
17-Nov-2010

From the MATLAB prompt, type:

>> epi_recon

This will prompt user to select Pfile with raw data.
Select the Pfile of a single slice 8 channel MRS sphere.

P13824.7



===================================================================
Notes:

1. Gradwarp correction (for gradient non-linearity) is not applied.
2. The file "ref.dat" contains phase correction coefficients for this scan.
3. The file "vrgf.dat" contains ramp sampling coefficients.

Tested with MATLAB 7.6.0 with Image Processing Toolkit.