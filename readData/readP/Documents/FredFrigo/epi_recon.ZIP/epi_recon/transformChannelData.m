% TRANSFORMCHANNELDATA - applies 2D Fourier transform to generate MR image
%
% Marquette University,   Milwaukee, WI  USA
% Copyright 2009, 2010 - All rights reserved.
%
%   IM_DATA = TRANSFORMCHANNELDATA(RAW_FRAMES) transforms raw images
%     in 3-dimensional image vector RAW_FRAMES with 2-D IDFT.
%    The image data is returned in 3-D vector FILTERED_DATA
% 
%    Author: Josh Marso - 02-Nov-2009
%            Fred Frigo - changes to support EPI recon 15-Nov-2010       
%     
% 
function im_data = transformChannelData(raw_frames)
    im_data = zeros(size(raw_frames));
    num_receivers = size(raw_frames,3);
    yres =size(raw_frames,1);
    xres = size(raw_frames,2);
    kspace = zeros(xres,yres);
         
    for r=1:num_receivers  
      kspace=raw_frames(:,:,r);
      % Perform row Fourier transform with FFTSHIFT (alteration)
      for m=1:yres
          kspace(m,:)=fftshift(ifft(ifftshift(kspace(m,:))));
      end
      % Perform column Fourier transform
      for k=1:xres
        kspace(:,k)=ifft(ifftshift(kspace(:,k)));
      end
      % Flip the complex image left-right to get correct orientation
      im_data(:,:,r)=fliplr(kspace);  
    end
end