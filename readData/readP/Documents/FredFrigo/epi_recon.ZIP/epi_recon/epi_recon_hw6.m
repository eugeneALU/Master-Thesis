% epi_recon.m  - Create MR image from Pfile 
%                with EPI phase correction and VRGF re-sampling
%
% This file derived from "B1UniformityMain.m"
%                 
% Marquette University,   Milwaukee, WI  USA
% Copyright 2010 - All rights reserved.
%
% Fred J. Frigo  02-Nov-2010
%
%
slice_no = 1; 
num_channels = -1;

% Enter name of Pfile
[fname, pname] = uigetfile('*.*', 'Select Pfile');
pfile = strcat(pname, fname);

%1: Read Pfile containing the raw data for each channel
[vrgf_raw_data, alternate, nreceivers] = getChannelData(pfile, slice_no, num_channels);

%1.5: Perform EPI phase correction and VRGF resampling
raw_data = phaseCorrectData(pfile, pname, slice_no, num_channels, vrgf_raw_data);

%2: Perform Fermi apodization and chopping
xdim = size(raw_data, 1);
% ffilter = fermi(xdim, 0.45*xdim, 0.1*xdim);

% Use a Hamming window in the frequency direction for apodization
ffilter = zeros(xdim);
for k=1:xdim
    ffilter(k,:)=hamming(xdim);
end
figure;
surf(ffilter);
filt_data = filterChannelData(raw_data, ffilter, alternate);

% display the k-space magnitude 
displayMagnitude(raw_data, 'K-space log-magnitude', 1);

%3: Transform to image domain
im_data = transformChannelData(filt_data);

%4a: Display the image magnitude
displayMagnitude(im_data, 'Image magnitude', 0);

%4b: Display the image phase
displayPhase(im_data, 'Image phase');

%5: obtain channel weights
weights = read_weights(pfile);

%6: calculate sum_square image
sos_image = sumOfSquares(im_data, weights);

%7: create DICOM image file  (added by Fred Frigo)
createDicomImage( sos_image);




















