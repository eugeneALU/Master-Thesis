% read_mr_image -  Read GEHC MR image 
% Marquette University
% Copyright 2009 - All rights reserved.
% Fred J. Frigo
%
% Sept 23, 2009   - Original
%
%                 The 'list_select_ex' utility can be used to extract
%                 this image from the image data base.
%  
% Note: the file "gems-dicom-dict.txt" (MR) can be found in this directory:
%       /export/home/sdc/app-defaults/dicom/gems-dicom-dict.txt
%

function  read_mr_image( dfile1, dict_file )

   if(nargin == 0)
       [fname, pname] = uigetfile('*.*', 'Select MR image');
       dfile1 = strcat(pname, fname);
 
       % Assume DICOM dictionary file is in SAME directory for now
       dict_file = strcat(pname, 'gems-dicom-dict.txt');   
   end
 
   % Set dictionary to the new DICOM DICTIONARY
   dicomdict('set', dict_file); 
   dictionary = dicomdict('get');
   
   % Get DICOM info from image.
   info1 = dicominfo(dfile1);
   exam = info1.StudyID;
   series = info1.SeriesNumber;
   image_number1 = info1.InstanceNumber;
   
   % Read image data from input image.
   I1 = dicomread(info1);
   
   % display the image
   figure;
   colormap('gray');
   imagesc(I1);
   plot_string1 = sprintf('Exam %s, series %d, image %d', exam, series, image_number1);
   title(plot_string1);
   
   % save the image as a binary file.
   % image_file_name = sprintf( 'e%s_s%d_i%d', exam, series, image_number1);
   image_file_name = dfile1;
   raw_image = strcat( image_file_name, '.raw_image');
   fid = fopen(raw_image, 'w+b', 'ieee-le');
   fwrite(fid, I1, 'integer*2');
   fclose(fid);
   
   % Create image files
   I2 = uint16(I1); %convert signed 16bit int to unsigned.
   png_image = strcat( image_file_name, '.png');
   jpg_image = strcat( image_file_name, '.jpg');
   
   %imwrite(I2, jpg_image, 'jpeg', 'Bitdepth', 16 ); %not OK  
   imwrite(I2, png_image, 'png', 'bitdepth', 16);
   
   amax=double(max(max(I2)));
   
   % scale 16 bit image to full dynamic range so it autodisplays better
   I3=uint16(double(I2).*(65535.0/amax)); 
   amax2=double(max(max(I3)));
   png_image1 = strcat( image_file_name, '.scaled.png');
   jpg_image1 = strcat( image_file_name, '.scaled.jpg'); 
   
   %imwrite(I3, jpg_image1, 'jpeg', 'Bitdepth', 16); %not OK
   imwrite(I3, png_image1, 'png', 'bitdepth', 16);
   
   % Reduce to 8bit iamges
   I4=uint8(double(I2).*(255.0/amax)); 
   amax3=max(max(I4));
   png_image2 = strcat( image_file_name, '.8bit.png'); 
   jpg_image2 = strcat( image_file_name, '.8bit.jpg');
   imwrite(I4, jpg_image2, 'jpeg', 'Mode', 'lossy', 'Quality', 75);
   imwrite(I4, png_image2, 'png', 'bitdepth', 8);
   
end       
 