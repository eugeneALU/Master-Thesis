% displayPhase - Displays the phase data for the provided array
%
% Marquette University,   Milwaukee, WI  USA
% Copyright 2009 - All rights reserved.
%
% Author: Josh Marso   02-Nov-2009
%  
%
% @param raw_frams array containing the raw data to be displayed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function displayPhase(raw_frames, plotString)
    num_frames = size(raw_frames,3);
    figure;
    plot_rows = num_frames/4;
    for i=1:num_frames
        subplot(plot_rows,4,i);
        imagesc(angle(raw_frames(:,:,i)));
        colormap('gray');
        title(sprintf('%s, receiver %d', plotString, i));
    end
end