% displayMagnitude - displays tmagnitude data for the provided array
%
% Marquette University,   Milwaukee, WI  USA
% Copyright 2009 - All rights reserved.
%
% Author: Jason Darby  02-Nov-2009 
%
% @param raw_frams array containing the raw data to be displayed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function displayMagnitude(raw_frames, plotString, logMagnitude)
    num_frames = size(raw_frames,3);
    figure;
    plot_rows = num_frames/4;
    for i=1:num_frames
        subplot(plot_rows,4,i);
        if (logMagnitude == 1)
            imagesc(log(abs(raw_frames(:,:,i))));
        else
            imagesc(abs(raw_frames(:,:,i)));
        end
        colormap('gray');
        title(sprintf('%s, receiver %d', plotString, i));
    end
end