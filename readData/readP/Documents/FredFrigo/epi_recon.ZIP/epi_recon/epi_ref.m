% epi_ref.m  - plot EPI phase correction coeffs from ref.dat file
% Fred Frigo
%
% Jul 28, 2002 - EPI phase correction coefficient plotting utility           
%

function  epi_ref( ref_file )

i = sqrt(-1);

if(nargin == 0)
    [fname, pname] = uigetfile('*.*', 'Select ref.dat file');
    ref_file = strcat(pname, fname);
end

% Open Pfile to read reference scan data.
fid = fopen(ref_file,'r', 'ieee-le');
if fid == -1
    err_msg = sprintf('Unable to locate ref.dat file %s', pfile)
    return;
end

% Read EPI Phase correction coefficients 
status = fseek(fid, 0, 'bof');
[hdr_value, count] = fread(fid, inf, 'real*4');
fclose(fid);


% Loop for each slice
num_slices = count / 1024
for slice = 1:num_slices    
  % Sort constant and linear coefficients for odd/even views  
  k_odd = 1;
  k_even = 1;
  k_start = ((slice-1)*1024)+1;
  k_stop = ((slice-1)*1024)+512;
  for k = k_start:k_stop
    % Assume non-zero coefs are not valid 
    if ( abs(hdr_value(k)+ abs(hdr_value(k+512))) > 0.000001 ) 
      if ( mod(k,2) == 1 ) 
         odd_constant(k_odd) = hdr_value(k);
         odd_linear(k_odd) = hdr_value(k+512);
         k_odd = k_odd + 1;
      else
         even_constant(k_even) = hdr_value(k);
         even_linear(k_even) = hdr_value(k+512);
         k_even = k_even + 1;
      end
   end
  end
  % Plot constant and linear coefficients
  figure;  %figure(slice);
  subplot(2,2,1);
  plot(odd_constant, 'r');
  title('Odd constant coefs');
  subplot(2,2,2);
  plot(even_constant, 'r');  
  title('Even constant coefs');
  subplot(2,2,3);
  plot(odd_linear, 'r');
  title('Odd linear coefs');
  subplot(2,2,4);
  plot(even_linear, 'r');
  title('Even linear coefs');
end