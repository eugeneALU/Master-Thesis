% vrgf_plot  - plot VRGF re-sampling coeffs from vrgf.dat file
% Fred Frigo
%
% Aug 25, 2005 - EPI phase correction coefficient plotting utility           
%

function  vrgf_plot( vrgf_file )


if(nargin == 0)
    [fname, pname] = uigetfile('*.*', 'Select vrgf.dat file');
    vrgf_file = strcat(pname, fname);
end

% Open file to read reference scan data.  
% Use 'ieee-be' for 12.0 and earlier
fid = fopen(vrgf_file,'r', 'ieee-le');
if fid == -1
    err_msg = sprintf('Unable to locate file: %s', pfile)
    return;
end

% Read VRGF coefficients 
status = fseek(fid, 0, 'bof');
[vrgf_value, count] = fread(fid, inf, 'real*4');
fclose(fid);

% This is the "prescribed" XRES:  64, 96, 128, 256
vrgf_xres=128

da_xres = count/vrgf_xres;

vrgf_matrix = zeros(vrgf_xres, da_xres );

for row = 1:vrgf_xres
    
    % Copy VRGF kernel for each row
    for m = 1:da_xres
        vrgf_matrix(row, m) = vrgf_value(((row-1)*da_xres)+m);
    end
end

figure;
imagesc(vrgf_matrix);
title('vrgf.dat');
xstring = sprintf('daxres = %d', da_xres);
ystring = sprintf('vrgf.xres = %d', vrgf_xres);
xlabel(xstring);
ylabel(ystring);
