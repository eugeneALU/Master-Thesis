% do_vrgf - Apply VRGF resampling
%
% Marquette University,   Milwaukee, WI  USA
% Copyright 2010 - All rights reserved.
%
%   This function will apply VRGF processing to a raw EPI data set
%   In order to work, the function must have access to the vrgf.dat file
%   which contains the interpolation coefficients for each resampled
%   data point.  Normally this is found in /usr/g/bin/vrgf.dat
%
%   Fred Frigo 02-Nov-2010
%
function vrgf_filtered = do_vrgf(data, rhdaxres, xres, rhdayres, vrgf_file);

debug = 0;

% read in vrgf.dat file
[ fd, message ] = fopen(vrgf_file,'r','ieee-le');

if (fd < 1) 
    error(message); 
end

% vrgf.dat contains "xres" columns of rhdaxres points
vrgf_filt = fread(fd,[rhdaxres, xres],'float');   

fclose(fd);

% Note the inner dimensions are the input xres (rhdaxres)
% Each output xres point is the sum (convolution) of the vrgf filter
% for that xres location

for i=1:(rhdayres)
      for j=1:xres
            vrgf_filtered(i,j) =  sum( data(i,:)*vrgf_filt(:,j) );     
      end
end

end