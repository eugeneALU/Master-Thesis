% phaseCorrectData - perform EPI phase correctiion and VRGF resampling
%
% Marquette University,   Milwaukee, WI  USA
% Copyright 2010 - All rights reserved.
%
% Author: Fred Frigo    02-Nov-2010
%
% @param pfile the path=filename to Pfile for scan parameters
% @param pname the path to "ref.dat" and "vrgf.dat" files
% @param slice_no - slice number within pass
% @param num_channels - number of channels
% @param input_raw_data - data before VRGF re-sampling & phase correction
%
% @return an array containing phase corrected and VRGF resampled raw data 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function raw_data = phaseCorrectData(pfile, pname, slice_no, num_channels, input_raw_data)
    i = sqrt(-1);
    my_slice = slice_no;
            
    % Open Pfile to read scan parameters.
    fid = fopen(pfile,'r', 'ieee-be');
    if fid == -1
        err_msg = sprintf('Unable to locate Pfile %s', pfile)
        return;
    end

    % Determine size of Pfile header based on Rev number
    status = fseek(fid, 0, 'bof');
    [f_hdr_value, count] = fread(fid, 1, 'real*4');
    rdbm_rev_num = f_hdr_value(1);
    if( rdbm_rev_num == 7.0 )
        pfile_header_size = 39984;  % LX
    elseif ( rdbm_rev_num == 8.0 )
        pfile_header_size = 60464;  % Cardiac / MGD
    elseif (( rdbm_rev_num > 5.0 ) && (rdbm_rev_num < 6.0)) 
        pfile_header_size = 39940;  % Signa 5.5
    else
        % In 11.0 (ME2) the header and data are stored as little-endian
        fclose(fid);
        fid = fopen(pfile,'r', 'ieee-le');
        status = fseek(fid, 0, 'bof');
        [f_hdr_value, count] = fread(fid, 1, 'real*4');
        if (f_hdr_value == 9.0)  % 11.0 product release
            pfile_header_size= 61464;
        elseif (f_hdr_value == 11.0)  % 12.0 product release
            pfile_header_size= 66072;
        elseif (f_hdr_value > 11.0) & (f_hdr_value < 100.0)  % 14.0 and later
            status = fseek(fid, 1468, 'bof');
            pfile_header_size = fread(fid,1,'integer*4');     
        else
            err_msg = sprintf('Invalid Pfile header revision: %f', f_hdr_value )
            return;
        end
    end

    status = fseek(fid, 0, 'bof');

    % Read header information
    [hdr_value, count] = fread(fid, 102, 'integer*2');
    fclose(fid);
    
    rhtype = hdr_value(29);
    npasses = hdr_value(33);
    nslices = hdr_value(35);
    nechoes = hdr_value(36);
    nframes = hdr_value(38);
    point_size = hdr_value(42);
    da_xres = hdr_value(52);
    da_yres = hdr_value(53);
    rc_xres = hdr_value(54);
    rc_yres = hdr_value(55);
    start_recv = hdr_value(101);
    stop_recv = hdr_value(102);
    nreceivers = (stop_recv - start_recv) + 1;
    
    % Use number of rows to determin image size - FF
    rc_xres = da_yres-1;
    rc_yres = rc_xres;

    % Determine number of slices in this Pfile:  this does not work for all cases.
    slices_in_pass = nslices/npasses

    % Compute size (in bytes) of each frame, echo and slice
    data_elements = da_xres*2*(da_yres-1);
    frame_size = da_xres*2*point_size;
    echo_size = frame_size*da_yres;
    slice_size = echo_size*nechoes;
    mslice_size = slice_size*slices_in_pass;

    % Name of vrgf.dat file
    vrgf_file = strcat(pname, 'vrgf.dat');

    % Name of ref.dat file
    ref_file = strcat(pname, 'ref.dat');

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Open ref.dat file to read EPI phase correction coeffs     %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ref_fid = fopen(ref_file,'r', 'ieee-le');
    if ref_fid == -1
        err_msg = sprintf('Unable to locate ref.dat %s', pfile)
        return;
    end

    % Read EPI Phase correction coefficients (from ref.dat file)
    ref_offset = (slice_no-1)*1024*nreceivers;
    status = fseek(fid, ref_offset, 'bof');
    
    for r=1:nreceivers
        [epi_pc_con(:,r), count] = fread(fid, 512, 'real*4'); % Constant coefficients
        [epi_pc_lin(:,r), count] = fread(fid, 512, 'real*4'); % Linear coefficients
    end
    fclose(ref_fid);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Perform EPI phase correction before VRGF                 %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
     % create alteration vector 
     vector_size = da_xres;
     alt= [1:vector_size];
     vtmp = [1:vector_size]; 
     alt = 1.0;
     for m=1:da_xres
         if( mod(m,2) == 0 )
            alt(m)=1.0;
         else
            alt(m)=-1.0;
         end
     end

     for m=1:da_xres
        x_index(m) = -(da_xres/2)-1+m;
     end
        
     for r=1:nreceivers
        % Create zero filled K space matrix
        raw_frames = zeros( da_yres -1,da_xres);
  
        % Read raw data for each row
        for m = 1:(da_yres-1)
           
            % apply alteration vector for each frame of data 
            vtmp=input_raw_data(m,:,r).*alt;
                     
            % Fourier transform each row of raw data
            raw_frames(m,:)=ifft(vtmp, da_xres);
            % Compute phase correction vectors from linear+constant terms
            phase_temp=(x_index.*epi_pc_lin(m,r)) + epi_pc_con(m,r);
            phase_correct=cos(phase_temp) + sin(phase_temp)*i;
      
            % Multiply Fourier transformed data by phase correction vector
            raw_frames(m,:)=raw_frames(m,:).*phase_correct;
   
            % Inverse Fourier transform phase corrected data
            raw_frames(m,:)=fft(raw_frames(m,:), da_xres);
            % Apply alteration vector
            raw_frames(m,:)=raw_frames(m,:).*alt;
            
            % Debug plot
            %if( m == ((da_yres-1)/2))
            %    figure();
            %    subplot( 2,1, 1);
            %    plot(x_index, unwrap(angle(input_raw_data(m,:,r))));
            %    title('Unwrapped phase at center of K-space');
            %    ylabel('Before Phase correction');
            %    subplot( 2,1, 2);
            %    plot(x_index, unwrap(angle(raw_frames(m,:))));
            %    ylabel('After Phase correction');
            %end
            
        end  % epi phase correction loop
        
        %Perform VRGF Re-sampling.
        raw_data(:,:,r) = do_vrgf(raw_frames(:,:), da_xres, rc_xres, da_yres-1, vrgf_file);
        
     end  % receiver loop

end