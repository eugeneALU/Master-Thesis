% createDicomImage - Create DICOM image using template header 
%                 
% Marquette University,   Milwaukee, WI  USA
% Copyright 2010 - All rights reserved.
%
% Fred J. Frigo  02-Nov-2010
%
function createDicomImage( my_image )
   % select existing DICOM image file to replicate header  
   [fname1, pname1] = uigetfile('*.*', 'Select DICOM image file');
   dfile = strcat(pname1, fname1);

   % Assume DICOM dictionary file is in SAME directory for now
   dict_file = strcat(pname1, 'gems-dicom-dict.txt'); 

   % Create name of NEW DICOM files to create
   new_dfile = strcat(dfile, '.new');
   
   % Set dictionary to the new DICOM DICTIONARY
   dicomdict('set', dict_file); 
   dictionary = dicomdict('get');
   
   % Get DICOM info from input image.
   info1 = dicominfo(dfile);
   exam = info1.StudyID;
   series = info1.SeriesNumber;
   image_number1 = info1.InstanceNumber;
 
   % Create a new DICOM image... starting with header from image1
   info = info1;
  
   % Create blank image (16 bit pixel data)- same size as image1
   % I = uint16(zeros(info1.Rows, info1.Columns)); % blank image
  
   info.WindowWidth  = max(max(my_image));  %default window width for new image
   info.WindowCenter = info.WindowWidth/2;  %defautl window level for new image
  
    % Multiply original series by 100 and add 30 for new series number
   info.StudyID = exam;
   info.SeriesNumber= series*100 +30;
   info.InstanceNumber = image_number1;
   info.SeriesInstanceUID = dicomuid;  %generate a new DICOM UID for new series
 
   % Create the new DICOM image  
   result = dicomwrite(my_image,new_dfile,'Dictionary',dictionary,info,'CreateMode','copy');

   % MATLAB doesn't like "gems-dicom.dict.txt"... just ignore
   msg=sprintf('New dicom file created = %s', new_dfile);
   msg

end